package com.merkzy.donutclient

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val requestCodeOverlay = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(0xFF101014.toInt())
        }
        val title = TextView(this).apply {
            text = "DONUT CLIENT"
            textSize = 25f
            setTextColor(0xFFF4F1FA.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Floating panel foundation · Android"
            textSize = 14f
            setTextColor(0xFFAAA5B5.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 28)
        }
        val start = Button(this).apply {
            text = "Enable floating panel"
            setOnClickListener { enableOverlay() }
        }
        val note = TextView(this).apply {
            text = "This build is an independent overlay interface. It does not read Minecraft memory, inspect hidden chunks, or reveal blocks through terrain."
            textSize = 13f
            setTextColor(0xFFAAA5B5.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(start)
        root.addView(note)
        setContentView(root)
    }

    private fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, requestCodeOverlay)
            return
        }
        startOverlayService()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCodeOverlay && Settings.canDrawOverlays(this)) {
            startOverlayService()
        }
    }

    private fun startOverlayService() {
        val intent = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
        else startService(intent)
        finish()
    }
}
