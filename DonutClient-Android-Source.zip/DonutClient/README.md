# Donut Client — Android overlay foundation

A Kotlin Android app that displays a user-controlled floating panel over other apps.

## Included
- Android overlay permission flow
- Foreground service with an ongoing notification
- Draggable floating bubble and expandable panel
- Clock toggle, compact-mode toggle, and panel pin toggle
- Persistent settings using SharedPreferences
- GitHub Actions workflow to build and publish a downloadable debug APK artifact

## Explicit scope
This is an overlay UI foundation only. It does not inspect Minecraft memory, read game files, access hidden chunk data, identify player bases, or render through-wall ESP. A normal Android overlay permission does not grant access to another app's private process or hidden world state.

## Build from an Android phone using GitHub Actions
1. Create a GitHub repository and upload the contents of this project to its `main` branch.
2. Open the repository's **Actions** tab.
3. Select **Build Donut Client APK** and tap **Run workflow** (or wait for the first push build).
4. Open the completed workflow run and download the `DonutClient-debug-apk` artifact.
5. Extract the artifact ZIP on Android and install `app-debug.apk`.

The APK is a debug build. Android may ask you to allow installation from the browser or file manager you used to download it.

## Build locally
Open this folder in Android Studio with Android SDK Platform 35 installed, allow Gradle sync, then use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Compatibility notes
- `minSdk 26` (Android 8.0)
- `targetSdk 35`
- `compileSdk 35`
- Uses the Android special-use foreground-service type for the persistent user-requested overlay.

## Verification
The source and GitHub Actions workflow are prepared. The APK has not yet been compiled or device-tested in this environment because Android SDK/Gradle tooling is not installed here. The workflow must run in GitHub Actions to produce the APK artifact.
