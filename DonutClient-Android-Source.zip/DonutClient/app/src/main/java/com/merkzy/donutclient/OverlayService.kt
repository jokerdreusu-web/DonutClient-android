package com.merkzy.donutclient

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.content.pm.ServiceInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: View? = null
    private var bubble: View? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("overlay", Context.MODE_PRIVATE) }
    private var showClock = true
    private var compact = false
    private var pinned = false
    private var clockView: TextView? = null

    private val clockTick = object : Runnable {
        override fun run() {
            clockView?.text = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            handler.postDelayed(this, 30_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showClock = prefs.getBoolean("show_clock", true)
        compact = prefs.getBoolean("compact", false)
        pinned = prefs.getBoolean("pinned", false)
        createNotificationChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(71, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(71, notification)
        }
        showBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun baseParams(width: Int, height: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            width, height, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun showBubble() {
        removePanel()
        if (bubble != null) return
        val size = dp(54)
        val button = TextView(this).apply {
            text = "M"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setBackgroundColor(0xFF6D45C7.toInt())
            setOnClickListener { showPanel() }
        }
        bubble = button
        val params = baseParams(size, size).apply { x = dp(18); y = dp(180) }
        bubbleParams = params
        makeDraggable(button, params)
        windowManager.addView(button, params)
    }

    private fun showPanel() {
        removeBubble()
        if (panel != null) return

        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(0xF019191F.toInt())
        }
        val header = TextView(this).apply {
            text = "DONUT CLIENT     ⋮"
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, dp(12))
        }
        outer.addView(header)

        if (!compact) {
            val section = TextView(this).apply {
                text = "OVERLAY"
                textSize = 11f
                setTextColor(0xFFB9A5F2.toInt())
                setPadding(0, dp(4), 0, dp(8))
            }
            outer.addView(section)
            outer.addView(toggleRow("Show clock", showClock) { checked ->
                showClock = checked
                prefs.edit().putBoolean("show_clock", checked).apply()
                refreshClock()
            })
            outer.addView(toggleRow("Compact mode", compact) { checked ->
                compact = checked
                prefs.edit().putBoolean("compact", checked).apply()
                refreshPanel()
            })
            outer.addView(toggleRow("Pin panel", pinned) { checked ->
                pinned = checked
                prefs.edit().putBoolean("pinned", checked).apply()
            })
        } else {
            val compactLabel = TextView(this).apply {
                text = "Compact panel is on"
                textSize = 13f
                setTextColor(0xFFE0DCE8.toInt())
                setPadding(0, 0, 0, dp(8))
            }
            outer.addView(compactLabel)
            outer.addView(actionButton("Expand settings") {
                compact = false
                prefs.edit().putBoolean("compact", false).apply()
                refreshPanel()
            })
        }

        if (showClock) {
            clockView = TextView(this).apply {
                textSize = 13f
                setTextColor(0xFFE0DCE8.toInt())
                setPadding(0, dp(8), 0, dp(8))
            }
            outer.addView(clockView)
        } else clockView = null

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
        }
        footer.addView(actionButton("Hide") { showBubble() })
        footer.addView(actionButton("Exit") { stopSelf() })
        outer.addView(footer)

        panel = outer
        val params = baseParams(dp(260), WindowManager.LayoutParams.WRAP_CONTENT).apply {
            x = dp(18); y = dp(180)
        }
        panelParams = params
        makeDraggable(header, params)
        windowManager.addView(outer, params)
        refreshClock()
    }

    private fun toggleRow(label: String, initial: Boolean, changed: (Boolean) -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(6))
        }
        val text = TextView(this).apply {
            this.text = label
            textSize = 14f
            setTextColor(0xFFF0EDF5.toInt())
        }
        val toggle = Button(this)
        toggle.text = if (initial) "ON" else "OFF"
        toggle.textSize = 11f
        toggle.minWidth = dp(58)
        toggle.setOnClickListener {
            val next = toggle.text.toString() != "ON"
            toggle.text = if (next) "ON" else "OFF"
            changed(next)
        }
        row.addView(text, LinearLayout.LayoutParams(0, dp(44), 1f))
        row.addView(toggle)
        return row
    }

    private fun actionButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 11f
        setOnClickListener { action() }
    }

    private fun makeDraggable(view: View, params: WindowManager.LayoutParams) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        view.setOnTouchListener { _, event ->
            if (pinned) return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    try { windowManager.updateViewLayout(view.rootView, params) } catch (_: Exception) { }
                    true
                }
                else -> false
            }
        }
    }

    private fun refreshClock() {
        handler.removeCallbacks(clockTick)
        if (showClock && clockView != null) handler.post(clockTick)
    }

    private fun refreshPanel() {
        val old = panelParams
        removePanel()
        showPanel()
        if (old != null && panelParams != null) {
            panelParams!!.x = old.x
            panelParams!!.y = old.y
            try { windowManager.updateViewLayout(panel, panelParams) } catch (_: Exception) { }
        }
    }

    private fun removePanel() {
        panel?.let { try { windowManager.removeView(it) } catch (_: Exception) { } }
        panel = null
        clockView = null
        handler.removeCallbacks(clockTick)
    }

    private fun removeBubble() {
        bubble?.let { try { windowManager.removeView(it) } catch (_: Exception) { } }
        bubble = null
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("overlay", "Floating panel", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, "overlay") else Notification.Builder(this)
        return builder.setContentTitle("Donut Client overlay")
            .setContentText("Floating panel is active")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        removePanel()
        removeBubble()
        super.onDestroy()
    }
}
